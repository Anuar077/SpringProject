package com.example.midterm.service;

import com.example.midterm.entity.MyOrder;
import com.example.midterm.model.OrderStatusEnum;

import java.util.List;

public interface IOrderService {
    List<MyOrder> getAll();
    List<MyOrder> getOrdersById(Long userId);
    MyOrder createNew(MyOrder order);
    MyOrder changeOrderStatus(Long orderId, OrderStatusEnum status);
}
