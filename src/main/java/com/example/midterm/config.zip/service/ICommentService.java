package com.example.midterm.service;

import com.example.midterm.entity.Comment;

import java.util.List;

public interface ICommentService {
    Comment createNew(Comment comment);
    Comment updateComment(Comment comment);
    void deleteCommentById(Long id);
    List<Comment> getCommentsByBookId(Long bookId);
}
