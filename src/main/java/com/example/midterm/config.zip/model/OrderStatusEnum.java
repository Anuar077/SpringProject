package com.example.midterm.model;

public enum OrderStatusEnum {
    IN_PROCESSING,
    EXPECT_DELIVERY,
    DELIVERED
}
