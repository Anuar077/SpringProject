package com.example.midterm.model;

public enum ShippingMethodEnum {
    YANDEX_GO,
    POSTKZ
}
