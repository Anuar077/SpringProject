package com.example.midterm.model;

public enum RoleEnum {
    USER,
    ADMIN
}
