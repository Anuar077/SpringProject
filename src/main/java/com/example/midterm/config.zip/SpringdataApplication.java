package com.example.midterm;

import com.example.midterm.entity.Book;
import com.example.midterm.entity.Person;
import com.example.midterm.repository.BookRepository;
import com.example.midterm.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Arrays;
import java.util.List;


@SpringBootApplication
public class SpringdataApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(SpringdataApplication.class, args);
    }

    @Autowired
    PersonRepository personRepository;
    BookRepository bookRepository;

    @Override
    public void run(String... args) throws Exception {
        Person a = new Person("FirstName", "FirstLastName", "FirstAddress");
        Person b = new Person("SecondName", "SecondLastName", "SecondAddress");
        Person c = new Person("ThirdName", "ThirdLastName", "ThirdAddress");
        List<Person> people = Arrays.asList(a, b, c);
        personRepository.saveAll(people);

        System.out.println("<<<<<<<<" + personRepository.findAll());
    }
}

